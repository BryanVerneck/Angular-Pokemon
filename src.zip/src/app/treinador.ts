
export class Treinador{
    id: number;
    nome: string;
}