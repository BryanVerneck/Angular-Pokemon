import { Treinador } from './treinador';

export const TREINADORES: Treinador[] = [
];