import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TreinadorService } from './treinador.service';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TreinadoresComponent } from './treinadores/treinadores.component';
import { TreinadorDetailComponent } from './treinador-detail/treinador-detail.component';
import { AppRoutingModule } from './app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    TreinadoresComponent,
    TreinadorDetailComponent,
    DashboardComponent,
  ],
  imports: [
    BrowserModule, 
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    
  ],
  providers: [TreinadorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
