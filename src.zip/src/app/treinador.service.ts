import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { Treinador } from './treinador';
import { TREINADORES } from './mock-treinadores';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

@Injectable({ providedIn: 'root' })

export class TreinadorService {
  
  private treinadorUrl: string = "http://localhost:8080/treinador";

  constructor(private http: HttpClient) {
    this.treinadorUrl;
  }

  public findAll(): Observable<Treinador[]> {
    return this.http.get<Treinador[]>(this.treinadorUrl);
  }

  public save(treinador: Treinador) {
    return this.http.post<Treinador>(this.treinadorUrl, treinador);
  }

  getTreinadores(): Observable<Treinador[]> {
    return of(TREINADORES);
  }

  getTreinador(id: number): Observable<Treinador> {
    return this.http.get<Treinador>(this.treinadorUrl + '/' + id);
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      return of(result as T);
    };
  }

  updateTreinador (treinador: Treinador): Observable<any> {
    return this.http.put(this.treinadorUrl, treinador, httpOptions).pipe(
      tap(catchError(this.handleError<any>('updateHero'))));
  }

  deleteTreinador (treinador: Treinador | number): Observable<Treinador> {
    const id = typeof treinador === 'number' ? treinador : treinador.id;
    const url = `${this.treinadorUrl}/${id}`;
  
    return this.http.delete<Treinador>(url, httpOptions).pipe(
      catchError(this.handleError<Treinador>('deleteHero'))
    );
  }

  addTreinador (treinador: Treinador): Observable<Treinador> {
    return this.http.post<Treinador>(this.treinadorUrl, treinador, httpOptions).pipe(
      catchError(this.handleError<Treinador>('addHero'))
    );
  }

}